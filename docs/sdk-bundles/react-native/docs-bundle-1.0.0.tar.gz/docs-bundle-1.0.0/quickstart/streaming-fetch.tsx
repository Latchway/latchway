  const send = async (): Promise<void> => {
    setBusy(true);
    setOutput("");
    try {
      const response = await client.fetch("/v1/responses", {
        method: "POST",
        latchwayFeature: deployment.feature,
        headers: {
          Accept: "text/event-stream",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: deployment.model,
          input,
          stream: true,
        }),
      });
      if (!response.ok) throw new Error(`Gateway returned HTTP ${response.status}.`);
      setStatus("Streaming response");
      await consumeStream(response, setOutput);
      setStatus(`Completed · request ${response.headers.get("X-Latchway-Request-ID") ?? "not supplied"}`);
    } catch (error) {
      setStatus(safeError(error));
    } finally {
      setBusy(false);
    }
  };
