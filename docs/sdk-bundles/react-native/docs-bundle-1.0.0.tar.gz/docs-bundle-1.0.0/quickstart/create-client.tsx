function makeClient(): LatchwayClient {
  return createLatchwayClient({
    baseURL: deployment.baseURL,
    applicationID: deployment.applicationID,
    environment: deployment.environment,
    identityProvider: "firebase",
    getIdentityToken: physicalConformanceEnabled()
      ? physicalIdentityToken
      : async () => {
        await ensureFirebaseApp();
        const user = firebaseAuth().currentUser;
        if (user === null) throw new Error("Sign in with Firebase before calling Latchway.");
        return user.getIdToken();
      },
    ...(deployment.googleCloudProjectNumber === undefined ? {} : {
      android: { playIntegrityCloudProjectNumber: deployment.googleCloudProjectNumber },
    }),
    ...(deployment.rootKeychainAccessGroup === undefined ? {} : {
      apple: {
        rootKeychainAccessGroup: deployment.rootKeychainAccessGroup,
        legacySharedKeychainAccessGroups: deployment.legacySharedKeychainAccessGroups,
      },
    }),
  });
}
