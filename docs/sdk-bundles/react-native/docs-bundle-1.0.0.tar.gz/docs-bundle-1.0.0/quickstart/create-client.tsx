function makeClient(): LatchwayClient {
  return createLatchwayClient({
    baseURL: deployment.baseURL,
    applicationID: deployment.applicationID,
    environment: deployment.environment,
    identityProvider: "firebase",
    getIdentityToken: physicalConformanceEnabled()
      ? physicalIdentityToken
      : developmentDeviceBootstrapEnabled()
        ? developmentIdentityToken
        : ordinaryIdentityToken,
    ...(deployment.googleCloudProjectNumber === undefined ? {} : {
      android: { playIntegrityCloudProjectNumber: deployment.googleCloudProjectNumber },
    }),
    ...(deployment.rootKeychainAccessGroup === undefined ? {} : {
      apple: {
        rootKeychainAccessGroup: deployment.rootKeychainAccessGroup,
        legacySharedKeychainAccessGroups: deployment.legacySharedKeychainAccessGroups,
      },
    }),
  });
}
