async function makeClient(): Promise<LatchwayClient> {
  await ensureFirebaseApp();
  const projectID = firebaseApp.app().options.projectId;
  if (!projectID) throw new Error("The application must configure its Firebase project ID.");
  const app = await Latchway.configure({
    baseURL: deployment.baseURL,
    applicationID: deployment.applicationID,
    environment: deployment.environment,
    identity: firebaseProject({projectID}),
    ...(deployment.googleCloudProjectNumber === undefined ? {} : {
      android: { playIntegrityCloudProjectNumber: deployment.googleCloudProjectNumber },
    }),
    ...(deployment.rootKeychainAccessGroup === undefined ? {} : {
      apple: {
        rootKeychainAccessGroup: deployment.rootKeychainAccessGroup,
        sharedKeychainAccessGroups: deployment.sharedKeychainAccessGroups,
      },
    }),
  });
  const account = await app.signIn({getIdToken: physicalConformanceEnabled()
    ? physicalIdentityToken : developmentDeviceBootstrapEnabled()
      ? developmentIdentityToken : ordinaryIdentityToken});
  return account.makeClient();
}
