# JavaScript client 1.1.1

This patch publishes only `@latchway/client`. Existing OpenAI, Vercel AI and
LangChain adapter peer ranges accept it without an adapter release.

`LatchwayError` preserves the gateway's safe message, code, status, request ID,
retryability, retry-after time, operation ID, feature, validation errors,
supported protocol versions, title and instance reference. Optional unknown
Problem extensions are ignored, never copied onto the public error. Known fields
and correlation remain strictly validated, including duplicate JSON rejection,
body-size limits, canonical documentation URLs and registered error semantics.

Use `errorFromResponse(response)` for unsuccessful direct-fetch responses.
Show `error.message` and `error.requestID` to explain and correlate failures;
use `error.validationErrors` for specific safe field guidance. Do not log entire
requests, tokens or provider response bodies. A retryable error is not permission
to automatically replay a request whose dispatch or streaming outcome is unknown.

The wire protocol and consumed contract remain unchanged. Source-level regression
tests are separate from physical-device or live provider verification.
