# Error handling (Android 1.2.2)

Control-plane operations throw `LatchwayException`. The SDK now preserves the
gateway's canonical error details across native and React Native callers:

- `code`, safe `message`, `title`, `httpStatus`, `requestId`, and `documentationUrl`.
- `retryable`, `retryAfter` (RFC 3339 reset time), and `retryAfterSeconds` (a valid
  numeric Retry-After header). Missing timing remains absent, never zero or one.
- `feature`, `errors` (bounded field paths and messages), and
  `supportedProtocolVersions`.
- `operationId` for indeterminate operations and optional `instance` for display
  or correlation only. Do not automatically follow the instance reference.

The existing exception constructor remains binary-compatible. Locally generated
errors have no gateway-only diagnostics. Lists default to empty.

## Direct OkHttp requests

The transport does not replace the response body with an exception, preserving
framework interoperability. Decode failures explicitly when you need their
Latchway metadata:

```kotlin
import dev.latchway.okhttp.latchwayException

http.newCall(request).execute().use { response ->
    response.latchwayException()?.let { error ->
        // Show error.message and error.requestId in your app's existing UI.
        // error.errors identifies fields the caller can fix.
        throw error
    }
    // Consume the successful response using your existing framework or parser.
}
```

`latchwayException()` returns null on a successful response without reading it.
For a failure it peeks at at most 512 KiB plus one overflow byte, leaving the
original body readable. A malformed, oversized or unreadable failure becomes
`RESPONSE_INVALID` with safe header correlation and HTTP status. The lower-level
`LatchwayException.fromResponse(LatchwayTransportResponse(...))` exposes the same
parser for custom transports.

## Retry and streaming safety

`retryable` describes whether a later attempt may work; it does not prove that
the previous request was never dispatched. Honor a supplied reset time. Do not
automatically replay streamed, one-shot or dispatch-indeterminate requests, or
retry requests that cannot fit their configured limit unchanged.

Android's SDK is transport-oriented and does not parse provider SSE protocols.
OkHttp read failures and cancellation propagate; they are not converted into
successful EOF. Your framework/parser must require its protocol's completion
marker, reject explicit error/failed/incomplete events, and not treat partial
text or HTTP 200 alone as proof of completion. Keep the original request ID for
support when a stream fails after headers arrive.

## Validation and redaction

Required Problem fields stay strict: known error code, canonical documentation
URLs, matching header/body request ID, status, and correctly typed values.
Known optional fields are bounded and validated; unknown optional extensions
are ignored for forward compatibility. No provider body, credential, proof or
raw verifier exception is used as a fallback message. Explicitly read the safe
diagnostic fields; `toString()` excludes their contents from routine logs.
