# Shared supplied identity (Android 1.1.0)

Configure public metadata once, supply a token, and use the native account. No
Firebase SDK, auth listener, identity-owner bootstrap or RN/native ordering switch
is required by Latchway. The existing app owns login and token refresh.

```kotlin
val app = LatchwayAppRegistry.configure(applicationContext, LatchwayAppOptions(
    baseUrl = "https://latchway.habitify.me/".toHttpUrl(),
    applicationId = "app_01M1RF27R52YQDHCTH2EZY6DHZ",
    environment = "development",
    identity = firebaseProject("habitify-dev"),
    playIntegrityCloudProjectNumber = 51819855588L,
))
val account = app.signIn { yourAuth.getIdToken() }
val client = account.makeClient()
val http = client.buildOkHttpClient()
// Set the configured feature on each gateway request:
val request = Request.Builder().url("https://latchway.habitify.me/v1/chat/completions")
    .latchwayFeature("habi-assistant")
    // Set the ordinary JSON body and POST method as required by your integration.
    .build()
```

`firebaseProject` only produces issuer/audience metadata. Other JWT providers use
`LatchwayIdentityConfiguration(providerId, issuer, audience, tenantId)` directly.
The gateway—not decoded JWT hints—validates identity. Supply the Latchway app
resource ID, not a Firebase app ID or Android package name. Play project numbers
remain explicit and independent of Firebase metadata.

## Sharing and authentication lifetime

- Matching native/RN configuration returns the existing native app; conflicting
  explicit settings fail. Standard manifest/signing/Play distribution remains
  the host application's responsibility.
- `app.currentAccount()` returns the existing opaque login, and
  `app.makeClient()` attaches to it without another sign-in.
- Use `account.updateIdToken { yourAuth.getIdToken() }` for the same user's new
  token. The gateway verifies it with installation-bound refresh possession;
  generation, keys and quota remain unchanged.
- Expired/missing supplied identity blocks protected work without retiring the
  account. A fresh verified update resumes that generation. Latchway never calls
  Firebase or an external provider to fetch a token itself.
- `account.logout()` retires the captured account across native and RN, including
  cached clients and components. A stale A handle cannot retire B. It is offline
  capable and does not reset user quota or sign out your external auth provider.
- `app.restore { ... }` is for initial auth restoration. It cannot undo recorded
  logout; an accepted new login calls `signIn` explicitly.
- Closing a client/RN surface does not log out the app. Fresh supplied ID tokens
  remain in native process memory after the JS runtime is destroyed. They are
  never persisted; supply identity again after process restart.

Prefer one-shot suspending token producers. Latchway captures the account intent
before invoking them and fences cancellation before late results may commit.
Already available tokens also use `signIn(idToken)` and `updateIdToken(idToken)`;
auth races that occurred before these calls are the application's responsibility.
Serialize your external auth mutations and report every logout/account change.

## Requirements and migration

Use server 1.1.1 or later, capability `supplied_identity_v1`, and contract 1.1.0/wire 3. The SDK
checks discovery and fails explicitly on older servers. New users establish an
attested session first; token updates call `/client/v1/sessions/identity`, never a
dummy model request. Expired session possession requires attested re-establishment
with the supplied token and the same unretired account key.

The default SDK stores follow the existing guarded legacy migration. Custom
legacy stores require an explicit audited cleanup callback and stable migration
identifier; they are never guessed. Existing authority-based registrations are
compatibility mode and cannot silently become supplied identity.

Install only the BOM and `latchway-okhttp` for this path. Core, Play Integrity and
all new helpers are Firebase-free. `latchway-firebase-auth` remains a separate
legacy compatibility artifact; do not add it to a new supplied-identity install.
All libraries advertise compile SDK 34; runtime minimum remains API 23. RN and
other application dependencies may impose their own higher host requirements.
