# Changelog

All notable changes to this project will be documented in this file.

The format follows Keep a Changelog, and releases will follow Semantic
Versioning once package publication begins.

## [1.1.0] - 2026-09-08

### Added

- Provider-neutral supplied identity: configure public issuer metadata, sign in
  with an app-supplied ID token, update the same account's token, and log out.
  No Firebase dependency or native Latchway bootstrap is needed by this path.
- Native-memory-only verified identity, gateway-backed token reauthentication,
  expiry suspension/recovery, guarded restoration, opaque account handles,
  cancellable one-shot token producers, and exclusive injected-auth binding leases.
- Shared-native app registry, deterministic identity ownership, explicit account
  activation/logout and native/RN session reuse in either configuration order.
- Offline account-generation retirement, atomic private-file lifecycle journals,
  cross-process credential fences, persistent legacy-constructor retirement and
  explicit custom legacy-store inventory hooks. Firebase remains optional.
- Independently keyed, account-scoped delegated components with AES-GCM
  persistence, bounded local key retention, revision-checked writes, and a
  rootless same-UID service entry point. Shared components use core-owned wire 3.
- Independent component transport leases, cancellation-safe shared refresh,
  buffered-response retirement checks and local migration/storage regressions.
- A validated `buildOkHttpClient()` integration that atomically installs the
  application interceptor, final network-origin guard, and gateway-scoped
  authenticator while preserving safe caller configuration and rejecting
  partial or duplicate manual hook assembly.

### Compatibility

- All published Android libraries compile against API 34 and publish
  `minCompileSdk=34`; runtime API 23 and hardware/attestation requirements remain.
- Shared mode requires contract 1.1.0, wire 3 and explicitly enabled native
  host policy. Legacy wire behavior is preserved outside a migrated shared scope.
- Supplied identity requires the gateway's `supplied_identity_v1` capability.
  Package publication is not physical Play-distributed verification evidence.

## [1.0.0] - 2026-09-01

### Added

- A run-bound, terminal one-use identity-JWT bootstrap for the Play-distributed
  conformance host, plus fail-closed unsigned Release AAB staging and isolated
  no-checkout signing with canonical source/core/contract/gateway metadata and hashes.
- Installation Family and configured client-component APIs with independent
  Android Keystore P-256 keys, encrypted refresh chains, delegated feature
  scope, child-only revocation, family-wide local key retirement, and redacted
  component diagnostics.
- Contract-owned framework metadata for the pinned OkHttp integration and
  exact route-policy tests for standard and restricted opaque data paths.
- Repository-only Retrofit, Aallam OpenAI Kotlin, and LangChain4j runtime
  conformance fixtures that reuse the production OkHttp hooks and control
  transport, verifying authorization, streaming, cancellation where exposed,
  bounded replay,
  framework-native error mapping, and credential redaction.

### Changed

- Synchronized runtime constants, canonical fixtures, Installation Family and
  Client Component operations, and framework metadata with released core contract
  `1.0.0` at current wire protocol `2`. The gateway's wire protocol `1`
  compatibility remains a legacy server behavior and is not emitted by this
  SDK candidate.

### Security

- The physical collector now revalidates the signed lease immediately before
  app-data reset and streams the identity JWT only over an Android shell-owned
  stdin pipe; the grant is never an argument, file, preference, log, Firebase
  session, or evidence field, cannot be staged or consumed twice, and is bound
  to the exact Latchway application, Android package, and identity provider.
  The v2 lease binds the exact compact-token SHA-256; after provider verification
  the trusted server atomically consumes that digest once, and signed teardown
  evidence requires the gateway receipt to bind the spent digest and lease.
  This remains compatible with Firebase ID tokens that do not carry `jti`.
- Upload-key material is unavailable to Gradle and repository candidate code.
  A canonical pre-sign payload manifest survives the signer boundary, and a
  separate no-secret verifier recomputes it before cryptographic verification.
  Byte-level ZIP validation rejects local/central metadata mismatches,
  alternate-name or unallowlisted extra fields, non-regular/special modes,
  overlaps, ambiguous descriptors, trailing/polyglot bytes, ZIP64, unsigned
  appended entries, deleted entries, partial signatures, extra signers, and
  certificate mismatch.
- The OkHttp network interceptor now issues a fresh DPoP proof for every
  permitted attempt, rejects indeterminate internal connection replay, and
  rejects same-origin requests outside the allowed Latchway data-plane paths,
  including encoded opaque-path traversal.

### Initial candidate baseline

#### Changed

- Established the initial SDK baseline; compatibility is declared for server `1.0.0`
  through the tested `1.0.x` series. The server-owned trusted input-accounting contract
  adds no client wire fields, and indeterminate-operation errors preserve their
  required operation ID.
- Server-confirmed installation revocation is terminal for that client,
  performs retryable non-cancellable state and DPoP-key cleanup, and prevents
  transport or reprovisioning with the revoked JKT; cleanup can fail over to a
  peer coordinator after a local key-reset failure.
- Cross-client refresh and persistence are coordinated by installation and
  session generation, stale responses cannot clear replacement grants, and a
  network origin guard blocks Latchway headers before cross-origin redirects.
- Android Keystore create, sign, and reset operations are coordinated per
  process-wide alias, and stale signer instances reject replacement keys.
- The conformance sample uses the supported OpenAI Chat route and requires an
  explicit non-secret model value.
- OkHttp runtime helpers remain compatible with API 23 and avoid retaining a
  strong static Android context.
- Gateway requests reject recognized caller-supplied provider credentials in
  headers, cookies, and query parameters before dispatch while replacing a
  caller Authorization header with Latchway DPoP authorization.
- Play Integrity challenges require a canonical server cloud project number
  that exactly matches the configured project before a token is requested.

#### Added

- Initial governance, contribution, security, and architecture documentation.
- Gradle 9.5/AGP 9.3 multi-module project for API 23 and newer.
- Android Keystore P-256 installation signer with StrongBox preference,
  hardware-backing policy, and redacted diagnostics.
- RFC 9449 DPoP proofs, RFC 7638 thumbprints, encrypted session persistence,
  and challenge/session/rotating-refresh single-flight coordination.
- Origin-pinned OkHttp authorization, bounded control transport, replay-safe
  authenticator, quota, revocation, and diagnostics APIs.
- Play Integrity Standard adapter using the server challenge hash directly as
  `requestHash`, with synchronized provider renewal and bounded retries.
- Optional Firebase Authentication adapter, BOM, test-support doubles, shared
  contract vectors, integration samples, and real Play-track conformance app.
- Explicit React Native Android wire identity that reuses native security while
  isolating its key and encrypted state namespace.
- Maven Central-compatible publications for the four public libraries and
  aligned BOM, including source/Javadoc artifacts, complete POM metadata,
  in-memory OpenPGP signing, and an explicit user-managed Central staging path.
- An isolated local Maven publication gate and independent offline Android
  consumer that resolves all public artifacts through the BOM, plus CI coverage
  that retains the verified repository as a test artifact.

#### Security

- Remote publication is absent unless explicitly enabled, Central secrets are
  read from environment or user-home properties only, and signing is rejected
  while configuration caching could persist credentials or key material.
