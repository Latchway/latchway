package dev.latchway.publicationsmoke

import android.content.Context
import dev.latchway.core.firebaseProject
import dev.latchway.okhttp.LatchwayAppOptions
import dev.latchway.okhttp.LatchwayAppRegistry
import okhttp3.HttpUrl.Companion.toHttpUrl

/** Compile-only binary consumer: this function is never executed by the fixture. */
internal suspend fun suppliedIdentityPublicApi(context: Context, idToken: String) {
    val app = LatchwayAppRegistry.configure(context, LatchwayAppOptions(
        "https://gateway.example.test/".toHttpUrl(), "app_01J00000000000000000000000", "development",
        firebaseProject("example-project"), 123456789L,
    ))
    val account = app.signIn { idToken }
    account.updateIdToken { idToken }
    account.makeClient().close()
    app.currentAccount()
    account.logout()
    app.signOut()
    app.signIn(idToken)
    app.signOut()
}
