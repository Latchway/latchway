class LangChain4jFrameworkConformanceTest {
    @Test
    fun langChain4jUsesItsOkHttpSpiWithTheLatchwayHooks() {
        val server = LoopbackHttpServer()
        server.enqueue(
            LoopbackResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json")
                .setBody(CHAT_COMPLETION),
        )
        server.start()
        val harness = FrameworkConformanceHarness(server)
        val resources = ClientResources()
        val model = OpenAiChatModel.builder()
            .baseUrl(server.url("/v1").toString())
            .apiKey(PROVIDER_PLACEHOLDER)
            .modelName("framework-fixture")
            .maxRetries(0)
            .httpClientBuilder(resources.langChainBuilder(harness))
            .build()

        try {
            val answer = model.chat("Say fixture")
            val recorded = server.takeDataRequest()

            assertEquals("fixture accepted", answer)
            assertEquals(2, server.controlRequestCount)
            assertEquals("POST /v1/chat/completions HTTP/1.1", recorded.requestLine)
            assertFrameworkAuthorization(recorded)
            assertTrue(recorded.body.readUtf8().contains("framework-fixture"))
        } finally {
            resources.close()
            harness.close()
            server.shutdown()
        }
    }
