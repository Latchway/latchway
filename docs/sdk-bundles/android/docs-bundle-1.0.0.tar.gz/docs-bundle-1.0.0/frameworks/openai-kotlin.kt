class OpenAiKotlinFrameworkConformanceTest {
    @Test
    fun aallamOpenAiKotlinUsesThePreconfiguredLatchwayOkHttpEngine() = runBlocking {
        val server = LoopbackHttpServer()
        server.enqueue(
            LoopbackResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json")
                .setBody(CHAT_COMPLETION),
        )
        server.start()
        val harness = FrameworkConformanceHarness(server)
        val http = harness.okHttpBuilder().build()
        val openAI = openAI(server, http)

        try {
            val completion = openAI.chatCompletion(request())
            val recorded = server.takeDataRequest()

            assertEquals("chatcmpl_latchway", completion.id)
            assertEquals(2, server.controlRequestCount)
            assertTrue(completion.choices.isNotEmpty())
            assertEquals("POST /v1/chat/completions HTTP/1.1", recorded.requestLine)
            assertFrameworkAuthorization(recorded)
            assertTrue(recorded.body.readUtf8().contains("framework-fixture"))
        } finally {
            close(openAI, http, harness, server)
        }
    }
