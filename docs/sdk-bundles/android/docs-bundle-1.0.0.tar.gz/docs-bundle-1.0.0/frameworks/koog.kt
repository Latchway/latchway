    @Test
    fun koogPreservesChatToolsAndStructuredOutputThroughLatchwayOkHttp() = runBlocking {
        val server = LoopbackHttpServer()
        server.enqueue(
            LoopbackResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json")
                .setBody(CHAT_COMPLETION),
        )
        server.start()
        val harness = FrameworkConformanceHarness(server)
        val fixture = koog(server, harness)
        val schema = buildJsonObject {
            put("type", "object")
            put("x-latchway-fixture", "structured-output")
        }
        val request = prompt(
            id = "koog-structured-fixture",
            params = OpenAIChatParams(
                schema = LLMParams.Schema.JSON.Basic("fixture_answer", schema),
            ),
        ) {
            user("Say fixture")
        }
        val tools = listOf(
            ToolDescriptor(
                name = "fixture_lookup",
                description = "Return deterministic fixture data",
            ),
        )

        try {
            val answer = fixture.client.execute(request, OpenAIModels.Chat.GPT4o, tools)
            val recorded = server.takeDataRequest()
            val body = JSONObject(recorded.body.readUtf8())

            assertEquals("fixture accepted", answer.textContent())
            assertEquals("POST /v1/chat/completions HTTP/1.1", recorded.requestLine)
            assertFrameworkAuthorization(recorded)
            assertEquals("fixture_lookup", body.getJSONArray("tools").getJSONObject(0)
                .getJSONObject("function").getString("name"))
            assertTrue(body.getJSONObject("response_format").toString().contains("structured-output"))
            assertFalse(body.toString().contains(PROVIDER_PLACEHOLDER))
        } finally {
            close(fixture, harness, server)
        }
    }
