    @Test
    fun retrofitUsesTheProductionHooksAndReplacesItsPlaceholderAuthorization() {
        val server = LoopbackHttpServer()
        server.enqueue(
            LoopbackResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json")
                .setBody("{\"id\":\"resp_retrofit\",\"status\":\"completed\"}"),
        )
        server.start()
        val harness = FrameworkConformanceHarness(server)
        val http = harness.okHttpBuilder().build()

        try {
            val response = retrofit(server, http).response(
                authorization = "Bearer $PROVIDER_PLACEHOLDER",
                body = "{\"model\":\"feature-selected-server-side\"}"
                    .toRequestBody(JSON),
            ).execute()
            val request = server.takeDataRequest()

            assertTrue(response.isSuccessful)
            assertEquals(2, server.controlRequestCount)
            assertFrameworkAuthorization(request)
            assertEquals("POST /v1/responses HTTP/1.1", request.requestLine)
            assertTrue(request.body.readUtf8().contains("feature-selected-server-side"))
        } finally {
            close(http, harness, server)
        }
    }

    @Test
    fun retrofitStreamingIsIncrementalAndCallCancellationReachesOkHttp() {
        val server = LoopbackHttpServer()
        server.enqueue(
            LoopbackResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "text/event-stream")
                .setChunkedBody(
                    chunks = listOf("data: first\n", "data: second\n"),
                    delay = 2,
                    unit = TimeUnit.SECONDS,
                ),
        )
        server.start()
        val canceled = CountDownLatch(1)
        val listener = object : EventListener() {
            override fun canceled(call: okhttp3.Call) {
                canceled.countDown()
            }
        }
        val harness = FrameworkConformanceHarness(server)
        val http = harness.okHttpBuilder(listener).build()

        try {
            val call = retrofit(server, http).stream(
                authorization = "Bearer $PROVIDER_PLACEHOLDER",
                body = "{}".toRequestBody(JSON),
            )
            val started = System.nanoTime()
            val response = call.execute()
            val first = checkNotNull(response.body()).source().readUtf8LineStrict()
            val elapsedMillis = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - started)

            assertEquals("data: first", first)
            assertTrue("first frame must arrive before the delayed second frame", elapsedMillis < 1_500)
            call.cancel()
            assertTrue(call.isCanceled)
            assertTrue("Retrofit cancellation must cancel the underlying OkHttp call", canceled.await(2, TimeUnit.SECONDS))
            assertEquals(2, server.controlRequestCount)
            assertFrameworkAuthorization(server.takeDataRequest())
        } finally {
            close(http, harness, server)
        }
    }
