    func prepareWidget() async {
        do {
            let client = try makeClient()
            let component = try ComponentExampleConfiguration.widget()
            let result = try await client.prepareComponents([component])
            let prepared = result.first?.containingAppActionRequired == false
            status = prepared ? "Widget key and one-time grant are prepared." : "Preparation needs attention."
            self.client = client
        } catch {
            status = safeDescription(error)
        }
    }

    func replaceWidget() async {
        do {
            let client = try makeClient()
            let component = try ComponentExampleConfiguration.widget()
            _ = try await client.replaceComponent(component)
            status = "The old component session is revoked and a new key is prepared."
            self.client = client
        } catch {
            status = safeDescription(error)
        }
    }

    func revokeFamily() async {
        do {
            let client = try client ?? makeClient()
            let component = try ComponentExampleConfiguration.widget()
            try await client.revokeCurrentInstallationFamily(retiring: [component])
            status = "The family is revoked and root/component Keychain material was erased."
            self.client = nil
        } catch {
            status = safeDescription(error)
        }
    }

    private func makeClient() throws -> LatchwayClient {
        let applicationID = try requiredInfo("LatchwayApplicationID")
        let environment = try requiredInfo("LatchwayEnvironment")
        let attestation = LatchwayAppAttestProvider(
            applicationID: applicationID,
            environment: environment,
            rootKeychainAccessGroup: try ComponentExampleConfiguration.rootKeychainAccessGroup(),
            legacySharedKeychainAccessGroups: ComponentExampleConfiguration.legacySharedKeychainAccessGroups()
        )
        return LatchwayClient(
            configuration: try ComponentExampleConfiguration.latchway(
                attestationProvider: attestation
            ),
            identityTokenProvider: LaunchEnvironmentIdentityProvider()
        )
    }
