# Changelog

All notable changes to this project will be documented in this file.

The format follows Keep a Changelog, and releases will follow Semantic
Versioning once package publication begins.

## [2.0.1] — 2026-09-10

### Fixed

- Preserve gateway Problem detail, retry timing, feature, field errors, supported
  protocol versions and diagnostic references across native request paths.
  Expose one bounded canonical `LatchwayProblem.decode` helper for custom transports;
  unknown optional extensions are ignored while known fields remain validated.
- Keep temporary discovery failures as gateway errors, not unsupported identity
  capabilities. Invalid HTTP error bodies retain status and safe request correlation,
  without exposing raw proxy/provider text.
- Read bounded Foundation Models HTTP error bodies. Rate-limit contexts retain the
  typed Problem and real reset date; other canonical errors retain their full Problem.
  Failed/truncated Responses streams retain request/generation IDs, never replay
  partial output, and never invoke tools from incomplete responses.
- Update LatchwayChat to display actionable validated details and request IDs.
  Generic error descriptions remain redaction-safe. No wire protocol, storage,
  authentication-provider dependency, or attestation-policy change is introduced.

## [2.0.0] — 2026-09-10

### Attestation development

- Document server-owned App Attest `development` / `production` / `any`
  acceptance without a new client environment flag or bypass. Add regression
  coverage for accepted-key replacement on Apple's `invalidKey`, persistence
  after acceptance, and retaining valid keys after an unacknowledged assertion.
  These are fixture tests, not physical local-build/TestFlight evidence.

### Breaking changes

- Make supplied-identity shared apps/accounts the only root client API. Remove
  old constructors, identity authorities, activation/transfer APIs, legacy
  Keychain inventories and adoption callbacks. Retain deny-only safety guards.
- Shared native accounts continue using wire protocol 3. Keep current account-generation isolation,
  offline logout, root-private storage, App Attest and component CAS retirement.
- Open delegated extensions using an explicit current-account handoff, not a
  root credential configuration. Retain unavailable direct-attestation guards; remove
  explicit legacy-inventory family-revocation APIs.
- Update current examples and documentation. The major version marks this source-breaking cleanup;
  prior published versions and historical release records are unchanged.
  No existing credentials are adopted or migrated. Deny-only extension markers
  remain checked as an intentional safety guard.

## [1.3.0] — 2026-09-09

### Added

- `try await app.signOut()` retires the shared native/React Native account
  without requiring a current account handle or generation snapshot. It also
  works during first sign-in, after token expiry and after process restart.
- Sign-out joins concurrent cleanup, fences late identity completions and old
  client streams, clears account credentials and registered component sessions,
  and persists logout intent even before the first account is activated.
- Incomplete secure-storage cleanup stays fail-closed and can be retried with
  the same app-level call. Explicit sign-in after success creates a fresh
  generation for the same or a different user.

### Compatibility

- Existing account `logout()` and generation-targeted APIs remain available;
  stale account callbacks cannot retire a later account. No wire or server
  upgrade, Firebase dependency or authentication-provider sign-out is added.
- Account-scoped installation/App Attest key identity and non-secret retirement
  markers remain under the existing bounded key-retention policy. This is local
  account sign-out, not remote installation revocation or unrelated Keychain
  erasure. Unit tests do not constitute fresh physical-device attestation proof.

## [1.2.0] — 2026-09-08

### Added

- Provider-neutral supplied JWT metadata, pure Firebase-project helper,
  memory-only verified identity, one-call App Attest configuration, opaque
  account handles and one-shot async sign-in/token update operations.
- Gateway-verified identity replacement using `supplied_identity_v1`; expired
  identity suspends access without retiring the account. A verified same-user
  update resumes the existing generation without resetting quota.
- Native sign-in cancellation tickets, guarded restoration after process death,
  exclusive optional auth-binding leases and independent RN/native session use.

- Shared native `LatchwayApp` registry, idempotent native/RN configuration,
  account-aware compatibility identity snapshots, explicit activation and serialized
  identity-authority transfer. Native/RN root clients share sessions/refresh,
  while every request receives its own DPoP proof.
- Captured-generation offline logout, persistent retirement/cleanup recovery,
  terminal old handles and client-only disposal/stream cancellation.
- Account-scoped delegated extension handoffs and revision-matched Keychain
  persistence. Cached responses and late credential writes observe cross-process
  retirement; credentials are erased separately from retained account keys.
- Bounded root/component key retention, exact legacy native/RN/group inventory,
  permanent legacy fences and an explicit native custom-store migration hook.
- LatchwayChat's native auth-owner lifecycle, sign-out during streaming,
  two-account UI/tool fencing and updated migration/extension guidance.

### Compatibility

- Shared mode requires the server-owned draft contract 1.1.0 / protocol 3 and
  explicit required native-host `sharedNativeCallers` policy. Legacy wire 2
  remains separate; no runtime downgrade or legacy credential adoption occurs.
- Fixture/CAS tests and local consumer builds are not signed Keychain,
  physical App Attest or extension proof; release verification reports them separately.

### Changed

- Require a fully resolved private root Keychain access group, prove it is the
  signed default before root work, explicitly scope every root/App Attest
  Security query, and fail closed when known root records remain in declared
  extension-shared groups.

## [1.1.0] - 2026-09-05

### Added

- Foundation Models OS 27 translation for `@Generable` / dynamic JSON schemas,
  structured transcript segments, enabled function definitions, tool calls and
  results across turns, tool-calling modes, reasoning context, request IDs, and
  bounded string/JSON-valued metadata.
- Greedy (temperature zero), unseeded nucleus (top-p), and top-k request
  translation. Top-k requires a compatible upstream; Responses does not expose
  a portable seed, so seeded requests fail explicitly instead of losing it.
- Bounded SSE decoding, reasoning summaries/signatures, terminal usage,
  refusal handling, and deferred tool dispatch: incomplete, failed, malformed,
  or disabled-tool responses cannot execute a local tool.
- Optional `Latchway/FoundationModels` CocoaPods subspec for iOS 27 with Xcode 27.
- LatchwayChat's Settings-selectable Foundation Models and Custom URLSession
  modes, live Open-Meteo weather tool, and physical two-turn smoke-test entry.

### Compatibility

- The core SDK keeps its iOS 15 minimum and wire protocol 2 / contract 1.0.0.
  Rich Responses requests require the companion gateway update; server 1.0.1
  rejects metadata and trusted-accounted tools/schemas.
- Requires server 1.0.2 for the expanded Foundation Models route. Images,
  seeded sampling, and encrypted reasoning under strict text-accounting quotas
  remain unsupported; see `Documentation/FoundationModels.md`.

## [1.0.0] - 2026-09-01

### Added

- Initial governance, contribution, security, and architecture documentation.
- Swift 6 package with iOS 15 deployment support and handwritten public APIs.
- Secure Enclave P-256 installation keys with explicit non-synchronizable
  Keychain software fallback policy.
- RFC 9449 DPoP, rotating sessions, actor single-flight refresh, authorization,
  quota, revocation, safe buffered retry, and redacted diagnostics.
- App Attest registration/assertion lifecycle with bounded invalid-key recovery.
- Optional Firebase token adapter, testing doubles, shared contract vectors,
  examples, and a physical-device conformance application.
- Paired native/React Native runtime identifiers plus nonce-aware authorization
  and single-flight forced refresh for safe caller-owned transport integration.
- Runtime-isolated native Keychain and App Attest namespaces, independently
  versioned client headers, and a build-linted CocoaPods App Attest subspec for
  React Native autolinking.
- Typed `operation_indeterminate` errors with their canonical audit correlation
  identifier preserved on the public problem value.
- A release-gated Swift Package and CocoaPods publication workflow, including
  a clean-tag/version preflight, nested consumer build, deterministic source
  archive, checksum, and credential-isolated CocoaPods publication required by
  the full React Native/iOS version 1 release.

### Changed

- Synchronized the 1.0.0 release with released core contract 1.0.0 at commit
  `d260e3d7485e9e1487b5e03922b79c7089d94ce2` and deterministic bundle SHA-256
  `4866aec1ff70e78d70f07847448161c2b59970fe102d95393b051444536d29a4`.
  New requests identify current wire protocol 2, while optional root metadata
  keeps compatible legacy wire-1 grant decoding fail-closed. The minimum server
  version is 1.0.0 and the maximum tested server series is 1.0.x.
- Hardened buffered and control-plane retries to require exact canonical,
  request-correlated pre-dispatch problems and one unambiguous printable-ASCII
  DPoP nonce; duplicate JSON members and ambiguous nonce headers fail closed.
- Expanded pre-session credential-leak rejection to the cross-SDK provider
  secret header/query alias set while retaining ordinary query parameters and
  cookie-free URLSession behavior.
- Closed an actor-reentrancy race that could make concurrent callers rotate an
  already-refreshed session a second time; scheduler-controlled regression
  coverage now proves one refresh and one persisted rotation per expiry.

- Previously synchronized the SDK with draft core contract 0.3.0 at commit
  `05f88b41813c210a23a459519abd3f7a9c3e45fa` and deterministic bundle SHA-256
  `ea265cfa750df8faeeaeac7bc60c04c4d907384205b5bf4d78a22a79dfc4d24c`.
  Wire protocol remains 1; the minimum server version is 0.3.0 and the maximum
  tested server series is 0.3.x.
- Previously synchronized the SDK with released core contract 0.5.1 at commit
  `2f5e5e67c824e270431f1232cc6dc2824848e380` and deterministic bundle SHA-256
  `52ebacd1e38c522b89bb14a1f34782176be32cdf91d22b7ab962003dbca2d754`.
  Wire protocol remains 1; the minimum server version is 1.0.0 and the maximum
  tested server series is 1.0.x.
